#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include "disastrOS.h"
#include "disastrOS_syscalls.h"

// Declare idle_pcb as external defined elsewhere
extern PCB* idle_pcb;

// replaces the running process with the next one in the ready list
void internal_schedule() {
  if (running) {
    disastrOS_debug("PREEMPT - %d ->", running->pid);
   }
  // at least one process should be in the ready queue
  // if not, no preemption occurs
  
  if (ready_list.first){
    // ... (tua logica di fine time-slice / gestione waiting ecc.)

    PCB* next = 0;
    if (ready_list.first) {
      next = (PCB*) List_detach(&ready_list, ready_list.first);
    } else {
    next = idle_pcb;   // FALLO: mai più running==NULL
    } 
running = next;
running->status = Running;

  }
  //disastrOS_printStatus();
 
  if (running) {
    disastrOS_debug(" %d\n", running->pid);
  }
}
