#include "coda_bloccante.h"
#include "pool_allocator.h"
#include "disastrOS_constants.h"
#include "disastrOS_resource.h"
#include "disastrOS_descriptor.h"
#include "disastrOS_globals.h"
#include "disastrOS.h"
#include "linked_list.h"
#include <assert.h>
#include <string.h>

/************************************************************
 * Parametri di configurazione                               
 * Puoi modificarli a seconda delle necessità del tuo sistema
 ************************************************************/
#define MAX_NUM_MESSAGEQUEUES   16   /* quante code totali può gestire il kernel */
#define MAX_MSGS_PER_QUEUE      64   /* capacità massima (numero messaggi) per coda */

/* Pool per le strutture MessageQueue ---------------------- */
#define MQ_SIZE         sizeof(MessageQueue)
#define MQ_MEMSIZE      (MQ_SIZE + sizeof(int))
#define MQ_BUFFER_SIZE  (MAX_NUM_MESSAGEQUEUES * MQ_MEMSIZE)

static char _mq_buffer[MQ_BUFFER_SIZE];
static PoolAllocator _mq_allocator;

/* Pool per i buffer circolari (array di void*) ------------- */
#define MQDATA_SIZE        (MAX_MSGS_PER_QUEUE * sizeof(void*))
#define MQDATA_MEMSIZE     (MQDATA_SIZE + sizeof(int))
#define MQDATA_BUFFER_SIZE (MAX_NUM_MESSAGEQUEUES * MQDATA_MEMSIZE)

static char _mqdata_buffer[MQDATA_BUFFER_SIZE];
static PoolAllocator _mqdata_allocator;

/************************************************************
 * Inizializzazione del modulo                              *
 * Chiama questa funzione una sola volta all'avvio del kernel
 ************************************************************/
void MessageQueue_initModule() {
    int res = PoolAllocator_init(&_mq_allocator,
                                 MQ_SIZE,
                                 MAX_NUM_MESSAGEQUEUES,
                                 _mq_buffer,
                                 MQ_BUFFER_SIZE);
    assert(!res);

    res = PoolAllocator_init(&_mqdata_allocator,
                             MQDATA_SIZE,
                             MAX_NUM_MESSAGEQUEUES,
                             _mqdata_buffer,
                             MQDATA_BUFFER_SIZE);
    assert(!res);
}

/* macro di supporto per buffer circolare */
#define NEXT_IDX(i, cap)   (((i) + 1) % (cap))

/******************************
 * disastrOS_mq_open          *
 ******************************/
int disastrOS_mq_open(int key, int flags, int capacity) {
    /* 1) Validazione argomenti */
    if (capacity <= 0 || capacity > MAX_MSGS_PER_QUEUE)
        return DSOS_ESYSCALL_ARGUMENT_OUT_OF_BOUNDS;

    /* 2) Cerco risorsa esistente con la stessa key */
    Resource* res = ResourceList_byId(&resources_list, key);
    if (res) {
        /* Se esiste già e l'utente chiede esclusività, errore */
        if (flags & DSOS_EXCL)
            return DSOS_ERESOURCENOEXCL;
    }
    else {
        /* Se non esiste, devo avere il flag CREATE per poterla fare */
        if (!(flags & DSOS_CREATE))
            return DSOS_ERESOURCENOFD;

        /* 3) Alloco la Resource globale */
        res = Resource_alloc(key, DSOS_RESOURCE_MQUEUE);
        if (!res)
            return DSOS_ERESOURCECREATE;

        /* 4) Alloco MessageQueue via PoolAllocator */
        MessageQueue* mq = (MessageQueue*) PoolAllocator_getBlock(&_mq_allocator);
        if (!mq) {
            Resource_free(res);
            return DSOS_ESYSCALL_OUT_OF_RANGE;
        }

        /* 5) Alloco il buffer circolare via PoolAllocator */
        void** buf = (void**) PoolAllocator_getBlock(&_mqdata_allocator);
        if (!buf) {
            PoolAllocator_releaseBlock(&_mq_allocator, mq);
            Resource_free(res);
            return DSOS_ESYSCALL_OUT_OF_RANGE;
        }

        /* 6) Inizializzo la struttura MessageQueue */
        mq->buffer   = buf;
        mq->capacity = capacity;
        mq->size     = 0;
        mq->head     = 0;
        mq->tail     = 0;
        List_init(&mq->send_wait);
        List_init(&mq->recv_wait);

        /* 7) Collego la MessageQueue alla Resource e la metto nella lista globale */
        res->resource = mq;
        List_insert(&resources_list, resources_list.last, (ListItem*) res);
    }

    /* 8) Creo un Descriptor per il processo corrente */
    running->last_fd++;
    int fd = running->last_fd;
    Descriptor* d = Descriptor_alloc(fd, res, running);
    if (!d)
        return DSOS_ESYSCALL_OUT_OF_RANGE;
    List_insert(&running->descriptors, running->descriptors.last, (ListItem*) d);

    /* 9) Creo il DescriptorPtr nella Resource */
    DescriptorPtr* dptr = DescriptorPtr_alloc(d);
    if (!dptr)
        return DSOS_ESYSCALL_OUT_OF_RANGE;
    List_insert(&res->descriptors_ptrs, res->descriptors_ptrs.last, (ListItem*) dptr);

    /* 10) Ritorno il file descriptor */
    return fd;
}

/******************************
 * disastrOS_mq_send          *
 ******************************/
int disastrOS_mq_send(int fd, void* msg, int len) {
    /* TODO:
       1. Recuperare MQDescriptor dal PCB (fd)
       2. Se coda piena -> bloccare processo in send_wait (List_pushBack + disastrOS_block)
       3. Copiare il messaggio in buffer[tail], aggiornare tail/size
       4. Se esiste un processo in recv_wait, svegliarlo (disastrOS_wakeup)
    */
     /* 1) Recupera il descriptor e la resource */
  Descriptor* d = DescriptorList_byFd(&running->descriptors, fd);
  if (!d) return DSOS_ERESOURCENOFD;
  Resource* res = d->resource;
  if (res->type != DSOS_RESOURCE_MQUEUE) return DSOS_ERESOURCENOFD;

  /* 2) Ottieni la MessageQueue */
  MessageQueue* mq = (MessageQueue*)res->resource;

  /* 3) Se la coda è piena, blocca il processo */
  if (mq->size == mq->capacity) {
    /* metti il PCB in attesa sulla coda send_wait */
    running->status = Waiting;
    List_pushBack(&mq->send_wait, &running->list);
    /* e contemporaneamente in waiting_list per il scheduler */
    List_pushBack(&waiting_list, &running->list);
    internal_schedule();  /* switch ad un altro processo */
  }

  /* 4) Inserisci il messaggio nel buffer circolare */
  mq->buffer[mq->tail] = msg;
  mq->tail = NEXT_IDX(mq->tail, mq->capacity);
  mq->size++;

  /* 5) Se ci sono receiver in attesa, svegliane uno */
  if (mq->recv_wait.first) {
    /* estrai il PCB dalla lista di recv_wait */
    ListItem* it = List_popFront(&mq->recv_wait);
    PCB* pcb = (PCB*)it;
    /* rimuovilo anche dalla waiting_list globale */
    List_detach(&waiting_list, &pcb->list);
    /* segna pronto e mettilo in ready_list */
    pcb->status = Ready;
    List_pushBack(&ready_list, &pcb->list);
  }

  return 0;
}

/******************************
 * disastrOS_mq_recv          *
 ******************************/
int disastrOS_mq_recv(int fd, void** buf, int len) {
    /* TODO:
       1. Recuperare MQDescriptor dal PCB (fd)
       2. Se coda vuota -> bloccare processo in recv_wait
       3. Prelevare messaggio da buffer[head], aggiornare head/size
       4. Se esiste un processo in send_wait, svegliarlo
    */
    /* 1) Recupera il descriptor e la resource */
    Descriptor* d = DescriptorList_byFd(&running->descriptors, fd);
    if (!d) return DSOS_ERESOURCENOFD;
    Resource* res = d->resource;
    if (res->type != DSOS_RESOURCE_MQUEUE) return DSOS_ERESOURCENOFD;
    /* 2) Ottieni la MessageQueue */
    MessageQueue* mq = (MessageQueue*)res->resource;
    /* 3) Se la coda è vuota, blocca il processo */
    if (mq->size == 0) {
        /* metti il PCB in attesa sulla coda recv_wait */
        running->status = Waiting;
        List_pushBack(&mq->recv_wait, &running->list);
        /* e contemporaneamente in waiting_list per il scheduler */
        List_pushBack(&waiting_list, &running->list);
        internal_schedule();  /* switch ad un altro processo */
    }
    /* 4) Preleva il messaggio dal buffer circolare */
    void* msg = mq->buffer[mq->head];
    mq->head = NEXT_IDX(mq->head, mq->capacity);
    mq->size--;
    /* 5) Se ci sono sender in attesa, svegliane uno */
    if (mq->send_wait.first) {
        /* estrai il PCB dalla lista di send_wait */
        ListItem* it = List_popFront(&mq->send_wait);
        PCB* pcb = (PCB*)it;
        /* rimuovilo anche dalla waiting_list globale */
        List_detach(&waiting_list, &pcb->list);
        /* segna pronto e mettilo in ready_list */
        pcb->status = Ready;
        List_pushBack(&ready_list, &pcb->list);
    }   
 /* 6) Copia il puntatore al messaggio nello spazio utente */
  *(void**)buf = msg;
  return 0;
}

/******************************
 * disastrOS_mq_close         *
 ******************************/
int disastrOS_mq_close(int fd) {
    /* TODO:
       1. Rimuovere MQDescriptor dal PCB
       2. Se ultimo descriptor, liberare resource e buffer
    */
    /* 1) Recupera Descriptor dal PCB */
    Descriptor* d = DescriptorList_byFd(&running->descriptors, fd);
    if (!d) 
        return DSOS_ERESOURCENOFD;
    Resource* res = d->resource;
    if (res->type != DSOS_RESOURCE_MQUEUE) 
        return DSOS_ERESOURCENOFD;

    /* 2) Rimuovi il DescriptorPtr dalla Resource */
    ListItem* it = res->descriptors_ptrs.first;
    while (it) {
      DescriptorPtr* dp = (DescriptorPtr*)it;
      it = it->next;
      if (dp->descriptor == d) {
        List_detach(&res->descriptors_ptrs, &dp->list);
        DescriptorPtr_free(dp);
        break;
      }
    }

    /* 3) Rimuovi il Descriptor dal PCB */
    List_detach(&running->descriptors, &d->list);
    Descriptor_free(d);

    /* 4) Se non ci sono più aperture, distruggi la coda */
    if (!res->descriptors_ptrs.first) {
        MessageQueue* mq = (MessageQueue*)res->resource;

        /* 4a) Svegli tutti i sender bloccati */
        while (mq->send_wait.first) {
          ListItem* x = List_popFront(&mq->send_wait);
          PCB* p = (PCB*)x;
          List_detach(&waiting_list, &p->list);
          p->status = Ready;
          List_pushBack(&ready_list, &p->list);
        }
        /* 4b) Svegli tutti i receiver bloccati */
        while (mq->recv_wait.first) {
          ListItem* x = List_popFront(&mq->recv_wait);
          PCB* p = (PCB*)x;
          List_detach(&waiting_list, &p->list);
          p->status = Ready;
          List_pushBack(&ready_list, &p->list);
        }

        /* 4c) Rimuovi Resource dalla lista globale */
        List_detach(&resources_list, &res->list);
        /* 4d) Libera buffer + struttura */
        PoolAllocator_releaseBlock(&_mqdata_allocator, mq->buffer);
        PoolAllocator_releaseBlock(&_mq_allocator, mq);
        /* 4e) Libera il Resource */
        Resource_free(res);
    }

    return 0;
}

/******************************
 * disastrOS_mq_unlink        *
 ******************************/
int disastrOS_mq_unlink(int key) {
    /* TODO:
       1. Cercare Resource con id=key
       2. Svegliare eventuali processi bloccati con errore
       3. Liberare memoria e rimuovere risorsa
    */
    /* 1) Trova la Resource per key */
  Resource* res = ResourceList_byId(&resources_list, key);
  if (!res)                   return DSOS_ERESOURCENOFD;
  if (res->type != DSOS_RESOURCE_MQUEUE) return DSOS_ERESOURCENOFD;
  MessageQueue* mq = (MessageQueue*)res->resource;

  /* 2) Sveglia tutti i sender bloccati */
  while (mq->send_wait.first) {
    ListItem* it = List_popFront(&mq->send_wait);
    PCB* p = (PCB*)it;
    List_detach(&waiting_list, &p->list);
    p->status = Ready;
    List_pushBack(&ready_list, &p->list);
  }
  /* 3) Sveglia tutti i receiver bloccati */
  while (mq->recv_wait.first) {
    ListItem* it = List_popFront(&mq->recv_wait);
    PCB* p = (PCB*)it;
    List_detach(&waiting_list, &p->list);
    p->status = Ready;
    List_pushBack(&ready_list, &p->list);
  }

  /* 4) Rimuovi la Resource dalla lista globale */
  List_detach(&resources_list, &res->list);

  /* 5) Libera buffer e struttura MessageQueue */
  PoolAllocator_releaseBlock(&_mqdata_allocator, mq->buffer);
  PoolAllocator_releaseBlock(&_mq_allocator,    mq);

  /* 6) Libera la Resource stessa */
  Resource_free(res);

  return 0;
}

